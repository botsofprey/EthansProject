package NewGame;
import java.awt.*;
import java.applet.*;

import javax.swing.JPanel;

import SnakeProgram.WindowHandler;

public class newGame extends Applet {
	static WindowHandler windowHandler;
	private static Dimension screenSize;
	private static player player;
	static boolean a = true;

	public static void main(String[] args) {
		windowHandler = new WindowHandler("title here");
		player = new player(windowHandler.getWindowSize());
		windowHandler.add(player);
		screenSize = windowHandler.getWindowSize();
	}

	public void paint(Graphics gr) {
		gr.fillRect(100, 100, 120, 120);
		gr.clearRect(40, 40, 50, 50);
	}

}
