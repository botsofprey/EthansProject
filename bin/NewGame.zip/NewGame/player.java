package NewGame;
import java.awt.Graphics;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;

public class player extends Canvas {
	private Dimension screenSize;

	public player(Dimension screenSize) {
		this.screenSize = screenSize;
		setBounds((int) (this.screenSize.getWidth()) / 2, (int) (this.screenSize.getHeight()) / 2, 10, 10);
		setBackground(Color.BLACK);
		setVisible(true);
	}
}
